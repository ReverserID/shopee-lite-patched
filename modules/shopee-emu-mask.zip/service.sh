#!/system/bin/sh
# Post-boot resetprop for props that break Android init if set in post-fs-data.sh.
# These are the ones SPSSDK native (libshpssdk.so) reads via getprop/__system_property_get
# to collect device fingerprint for the af-ac-enc-sz-token sign. Setting them AFTER
# SystemUI/Launcher init avoids the boot-loop that happens when ro.product.* changes
# during init.

# Wait boot complete
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done
sleep 10  # let launcher stabilize

# Spoof model/brand/manufacturer — SPSSDK reads these.
# Values chosen to look like real TECNO device (lower risk score vs emulator-indicating names).
resetprop -n ro.product.model "TECNO BD4"
resetprop -n ro.product.brand "TECNO"
resetprop -n ro.product.manufacturer "TECNO MOBILE LIMITED"
resetprop -n ro.product.device "TECNO-BD4"
resetprop -n ro.product.name "BD4-OP"
resetprop -n ro.product.cpu.abi "arm64-v8a"
resetprop -n ro.product.cpu.abilist "arm64-v8a,armeabi-v7a,armeabi"
resetprop -n ro.product.cpu.abilist64 "arm64-v8a"
resetprop -n ro.product.cpu.abilist32 "armeabi-v7a,armeabi"
resetprop -n ro.build.product "BD4-OP"
resetprop -n ro.build.fingerprint "TECNO/BD4-OP/TECNO-BD4:14/UP1A.231005.007/173010:user/release-keys"
resetprop -n ro.build.flavor "BD4-user"
resetprop -n ro.build.id "UP1A.231005.007"
resetprop -n ro.build.display.id "BD4-14.5.0.173SP01(OP01BZ)"

echo "emu-mask post-boot resetprop done: $(date)" > /cache/emu_mask_post_boot.log
