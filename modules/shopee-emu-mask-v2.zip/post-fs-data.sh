#!/system/bin/sh
# Shopee Emu Mask - safe subset (don't break SystemUI/Launcher)
MODDIR=${0%/*}

# Only kernel-level emu flags; app-visible build props left untouched
# (modmenu's EmuHooks already spoofs Build.* fields at Java level per-app)
resetprop -n ro.kernel.qemu 0
resetprop -n ro.kernel.qemu.gles 0
resetprop -n ro.hardware qcom
resetprop -n ro.boot.hardware qcom
resetprop -n ro.boot.selinux enforcing

# Bind-mount spoofed /proc/cpuinfo (what libshpssdk's native code reads)
SPOOF=$MODDIR/cpuinfo.spoof
cat > $SPOOF <<'EOF'
processor	: 0
vendor_id	: ARM
model name	: ARMv8 Processor rev 2 (v8l)
BogoMIPS	: 38.00
Features	: fp asimd evtstrm aes pmull sha1 sha2 crc32
CPU implementer	: 0x41
CPU architecture: 8
CPU variant	: 0x1
CPU part	: 0xd41
CPU revision	: 2

processor	: 1
vendor_id	: ARM
model name	: ARMv8 Processor rev 2 (v8l)
BogoMIPS	: 38.00
Features	: fp asimd evtstrm aes pmull sha1 sha2 crc32
CPU implementer	: 0x41
CPU architecture: 8
CPU variant	: 0x1
CPU part	: 0xd41
CPU revision	: 2

Hardware	: Qualcomm Technologies, Inc SM8450
EOF
chmod 0444 $SPOOF
mount --bind $SPOOF /proc/cpuinfo 2>/dev/null
